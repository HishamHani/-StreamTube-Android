# Google / YouTube account integration (Flow GitHub flavor)

The GitHub flavor includes an opt-in Google authorization panel in **Settings → Integrations**. It uses Google Play services' `AuthorizationClient` and the official YouTube Data API v3. The FOSS flavor intentionally excludes the Google Play services dependency and does not show this panel.

## Google Cloud configuration required before sign-in can work

1. Create or select a project in [Google Cloud Console](https://console.cloud.google.com/).
2. Enable **YouTube Data API v3** for that project.
3. Configure the Google Auth Platform consent screen and add test users while the app is in testing.
4. Create an **Android OAuth client** for the application ID `io.github.aedev.flow`.
5. Register the SHA-1 signing certificate fingerprint for the exact build you will install. Run `./gradlew :app:signingReport` to inspect local debug/release fingerprints. A release build signed with a different key needs its own matching fingerprint.
6. Publish the OAuth consent screen / complete Google's verification requirements before distributing the integration broadly. Google may show an unverified-app warning while the consent screen remains in testing or unverified.

No client secret or API key is embedded in the Android app. Google Play services handles the native authorization interaction; the app requests only `https://www.googleapis.com/auth/youtube.readonly` and sends the resulting short-lived access token in the HTTP `Authorization: Bearer` header.

## Current feature coverage

- Connect / re-authorize a Google account.
- Switch the selected Google account.
- Disconnect and revoke the requested YouTube read permission.
- Read the authenticated channel, up to 50 subscriptions, up to 50 playlists, the first 10 playlists' first 10 items, and up to 50 liked videos (subject to the user's granted scope and YouTube API eligibility).
- Store the access token encrypted at rest with AES-GCM using a non-exportable Android Keystore key.

The token is an access token, not a refresh token. The Google authorization SDK manages the user's grant and the **Reconnect / refresh** action obtains a usable access token again when required. This client-only implementation does not request offline server access or store a Google client secret.

## Important limitations

- The integration is read-only. It does not create/delete playlists, subscribe/unsubscribe channels, upload videos, post comments, or modify ratings.
- YouTube Data API quotas and account/API eligibility rules apply. Only the first page of each list is currently displayed.
- Google Play services must be available on the device. The FOSS flavor intentionally remains independent of Google Play services.
- Google must approve the OAuth consent configuration for public distribution. Source code alone cannot register the app or complete Google's verification process.
